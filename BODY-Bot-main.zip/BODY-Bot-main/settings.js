const settings = {
  packname: 'بودي اليوتيوبر',
  author: '‎',
  botName: ".⤹𝗕𝗢𝗗𝗬 𝗘𝗟 𝗬𝗢𝗨𝗧𝗨𝗕𝗘𝗥⤾.",
  botOwner: 'مطور بودي اليوتيوبر', // Your name
  ownerNumber: '201018145430', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
